//
//  SplashViewModel.swift
//  Rangoo
//
//  Created by coltec on 19/06/23.
//

import Foundation
import SwiftUI

class SplashViewModel: ObservableObject{
    
    @Published var uiState: SplashUIState = .loading
    
    func onAppear(){
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.uiState = .goToSignInScreen
        }
    }
    
    
}

extension SplashViewModel{
    func signInView() -> some View{
        return SplashViewRouter.makeSignInView()
    }
}


