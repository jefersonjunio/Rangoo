//
//  SplashViewRouter.swift
//  Rangoo
//
//  Created by coltec on 19/06/23.
//

import SwiftUI

enum SplashViewRouter{
    
    static func makeSignInView() -> some View{
        let viewModel = SignInViewModel()
        return SignInView(viewModel: viewModel)
    }
    
}
