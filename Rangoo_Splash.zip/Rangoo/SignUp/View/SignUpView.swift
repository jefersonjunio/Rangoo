//
//  SignUpView.swift
//  Rangoo
//
//  Created by Rangoo Group on 13/06/23.
//

import SwiftUI
import Combine

struct SignUpView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
    }
}
